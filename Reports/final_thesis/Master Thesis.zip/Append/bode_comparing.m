spring_damping_vec = [100 150 200 250 300 350 400];
%k_op = 200
%b_op = 20
K_P = 0.2
K_I = 0.0
K_D = 0.0

K_PID2Vardu = 1/51 % [V]
um_gain = -1000000 % [um/m]
K_ampl = 10 % V/V
n = 112 % reduction ration [-]
J_T = 1.25E-3 / n / n % kg*m^2
L_CL = 20E-3
k_eq = 6000 % N/m
m_2 = 7E-3 % kg
L_a = 5.8E-3 % H
R_a  = 118.6 % Ohm
efficiency = 0.6 % [-]
K_tau = efficiency*31.4E-3 % [Nm/A]
K_emf = 3.29E-3 / 60 % [V/s]
s = tf('s');
%z = tf('z',dT) % Used for discretization
%s = (1-z^-1)/dT % Used for discretization
dT = 0.001;

%experim K_P = 0.2; K_I = 0; K_D = 0
freq_vec = [1.25, 1.6, 100.0, 10.0, 13.0, 16.0, 1.0, 2.5, 20.0, 25.0, 2.0, 32.0, 3.0, 40.0, 4.0, 50.0, 5.0, 6.3, 63.0, 80.0, 8.0]
amplitude_factor_l = [0.8021762720531634, 0.8054151390569485, 0.015545101680621341, 1.0773667825505355, 1.1642926077392948, 1.1103451508176316, 0.8001758873970981, 0.814056941660425, 0.8809965954959127, 0.5443027780892209, 0.8080825031462602, 0.2796958251080355, 0.8204548508774807, 0.16228564296355955, 0.8471466599918783, 0.10547366728162677, 0.8705112782697394, 0.9245682579252669, 0.05343340955353186, 0.024603192099363968, 0.9978075966054786]
phasediff_l = [-13.338637077482488, -14.09045739088748, -215.85673669598538, -48.04116200227554, -73.34441078067667, -100.25217048165923, -13.120541509581287, -16.085908849961044, -133.37888476020055, 201.4902985359118, -14.874321828402891, -176.09087916984802, 342.54636240739, 172.0658999860665, 339.59240015589626, 160.15771192477212, -23.728405952504453, -28.567395522204393, 147.9917576755808, 149.19385839692242, -36.037447598503036]
amplitude_factor_r = [0.7259689909042475, 0.735561475713898, 0.011847747061743118, 0.7807616430080885, 0.6652857160264002, 0.4684605400670259, 0.7127722160221738, 0.7461571487258002, 0.28422778003510263, 0.18648071556469148, 0.7439708501454618, 0.10739962887725536, 0.7525359007020068, 0.07014225593098215, 0.7786568428021221, 0.04585663312767849, 0.8100457909516678, 0.8245672101098731, 0.02640620952087805, 0.017672001900720043, 0.8172666256439353]
phasediff_r = [-16.647751016192103, -18.17293749217521, -237.48339557890603, -84.206485995129, -110.7789491948499, -133.2352471671927, -15.490775194720683, -22.931547230698484, -154.12969771290278, 194.1127967504471, -20.088130391155154, -178.43503982578886, 334.0056876428433, 172.21922748081028, 327.9483761537956, -190.87105537800483, -39.46722121664876, -49.247314509247005, 153.90271170189118, 138.0318425466486, -64.3717766560425]


phasediff_l = -(phasediff_l>0)*360 + phasediff_l;
phasediff_r = -(phasediff_r>0)*360 + phasediff_r;
[f_sort, I] = sort(freq_vec)

for k = 1:length(spring_damping_vec)
    b_sp = spring_damping_vec(k)

    % blocked by walls
    a = um_gain*(K_P + K_D*s + K_I/s);
    b = K_PID2Vardu*K_ampl;
    c = -n/L_CL;
    d = (L_a*s + R_a);
    e = (k_eq + b_sp*s)*L_CL/n;
    my_transfer = tf(K_tau*a*b/(c*d*s^2*J_T - e*d + K_emf*K_tau*c*s + a*b*K_tau))
    % Plot figure and save
    fig = figure('units','normalized','outerposition',[0 0 1 1]);
    semilogx(f_sort, 20*log10(amplitude_factor_l(I')), '*-', 'Color', 'r')
    hold on
    semilogx(f_sort, 20*log10(amplitude_factor_r(I')), '*-', 'Color', 'k')
    PlotHandle= bodeplot(my_transfer);
    semilogx(f_sort, phasediff_l(I'), '*-', 'Color', 'r')
    semilogx(f_sort, phasediff_r(I'), '*-', 'Color', 'k')
    h = gcr
    ylims{1} = [-50, 10];
    ylims{2} = [-250, 10];
    setoptions(h,'FreqUnits','Hz','YLimMode','manual','YLim',ylims);
    set(findall(fig, 'type','axes'),'fontsize',16)
    PlotOptions= getoptions(PlotHandle);
    PlotOptions.Title.String= '';
    PlotOptions.XLabel.FontSize= 20;
    PlotOptions.YLabel.FontSize= 20;
    PlotHandle.setoptions(PlotOptions)
    legend(strcat('Analytical: b_{sp} = ', num2str(spring_damping_vec(k)), 'Ns/m'), 'Experimental data left','Experimental data right', 'Location', 'SouthWest')

    set(findall(gcf,'Type','line'),'LineWidth',4)
    xlim([1 120])
    grid on
    hold on
    filename = ['figures/bode_sp_damp' num2str(spring_damping_vec(k))];%backward_
    saveas(gcf, [filename  '.jpg'])
    dot_pos = strfind(filename,'.');
    if (dot_pos)
        saveas(gcf, [filename(1:dot_pos-1) filename(dot_pos+1:end)  '.m'])
    else
        saveas(gcf, [filename  '.m'])
    end
    close(fig)
end